#!/usr/bin/env python3


from brain_games.logic.calc_logic import calc_game


def main():
    calc_game()


if __name__ == '__main__':
    main()


