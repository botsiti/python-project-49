## Игры
### Игра Brain-even
Суть игры в следующем: пользователю показывается случайное число. И ему нужно ответить *yes*, если число чётное, или *no* — если нечётное:

[![asciicast](https://asciinema.org/a/545803.svg)](https://asciinema.org/a/545803)

### Hexlet tests and linter status:
[![Actions Status](https://github.com/botsiti/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/botsiti/python-project-49/actions)

### Codeclimate Maintainability:
[![Maintainability](https://api.codeclimate.com/v1/badges/d9677d92c9612c6f2509/maintainability)](https://codeclimate.com/github/botsiti/python-project-49/maintainability)
