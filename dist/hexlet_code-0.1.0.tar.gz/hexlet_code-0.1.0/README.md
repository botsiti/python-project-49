## Игры
### Игра Brain-even
Пользователю показывается случайное число. И ему нужно ответить *yes*, если число чётное, или *no* — если нечётное:

[![asciicast](https://asciinema.org/a/545803.svg)](https://asciinema.org/a/545803)

### Игра Brain-calc
Пользователю показывается случайное математическое выражение, например 35 + 16, которое нужно вычислить и записать правильный ответ.

[![asciicast](https://asciinema.org/a/TFhigohoAuozr73WXebh0qqS2.svg)](https://asciinema.org/a/TFhigohoAuozr73WXebh0qqS2)


### Hexlet tests and linter status:
[![Actions Status](https://github.com/botsiti/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/botsiti/python-project-49/actions)

### Codeclimate Maintainability:
[![Maintainability](https://api.codeclimate.com/v1/badges/d9677d92c9612c6f2509/maintainability)](https://codeclimate.com/github/botsiti/python-project-49/maintainability)
