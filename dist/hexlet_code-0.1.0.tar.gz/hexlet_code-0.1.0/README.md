### Hexlet tests and linter status:
[![Actions Status](https://github.com/botsiti/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/botsiti/python-project-49/actions)

### Codeclimate Maintainability:
[![Maintainability](https://api.codeclimate.com/v1/badges/d9677d92c9612c6f2509/maintainability)](https://codeclimate.com/github/botsiti/python-project-49/maintainability)
