# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.logic', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Terminal mini-games for your brain',
    'long_description': "[![Actions Status](https://github.com/botsiti/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/botsiti/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/d9677d92c9612c6f2509/maintainability)](https://codeclimate.com/github/botsiti/python-project-49/maintainability)\n\n## Project Settings and Installation\n### Requirements\n[Python](https://www.python.org/) version = ^3.10\n[Poetry](https://python-poetry.org/) version = 1.3.1 + \n### Installation & Makefile settings\n**1) Clone the project** - `git clone git@github.com:botsiti/python-project-49.git`\n**2) Install package to poetry's .venv** - `make install`\n**3) Publish project** - `make publish`\n**4) Install project on your computer** - `make package-install`\n\n---\n\n## Games\n###  Brain-even\nThe user is shown a random number. If the number is even - the correct answer is *yes*, otherwise *no*:\n[![asciicast](https://asciinema.org/a/545803.svg)](https://asciinema.org/a/545803)\n\n### Brain-calc\nThe user is shown a random math expression, for example **35 + 7**. The user must write down the correct answer. In this example the answer is **42** :\n[![asciicast](https://asciinema.org/a/TFhigohoAuozr73WXebh0qqS2.svg)](https://asciinema.org/a/TFhigohoAuozr73WXebh0qqS2)\n\n### Brain-GCD\nThe user is show two random numbers, for **25** **50**. The user must calculate and enter the greatest common divisor of these numbers. In this example the answer is **25** :\n[![asciicast](https://asciinema.org/a/dsxTskNy8nxPW9CFDmRdSuyrh.svg)](https://asciinema.org/a/dsxTskNy8nxPW9CFDmRdSuyrh)\n\n### Brain-Progression\nThe user is shown a series of numbers creating an **arithmetic progression**, but one number is hidden by two dots. The user must write down this number:\n[![asciicast](https://asciinema.org/a/hBlQbRpRspMOLZGvInWJjiVGi.svg)](https://asciinema.org/a/hBlQbRpRspMOLZGvInWJjiVGi)\n\n\n### Игра Brain-Prime\nThe user is shown a random number. The user must write down *yes*, if the number is prime, otherwise *no*:\n[![asciicast](https://asciinema.org/a/C7sKZ9vcnhdEXdcdJ408hwJUG.svg)](https://asciinema.org/a/C7sKZ9vcnhdEXdcdJ408hwJUG)\n",
    'author': 'batraz',
    'author_email': 'batrazbotsiev@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/botsiti/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
