# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.logic', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '## Игры\n### Игра Brain-even\nПользователю показывается случайное число. И ему нужно ответить *yes*, если число чётное, или *no* — если нечётное:\n\n[![asciicast](https://asciinema.org/a/545803.svg)](https://asciinema.org/a/545803)\n\n### Игра Brain-calc\nПользователю показывается случайное математическое выражение, например **35 + 16**, которое нужно вычислить и записать правильный ответ:\n\n[![asciicast](https://asciinema.org/a/TFhigohoAuozr73WXebh0qqS2.svg)](https://asciinema.org/a/TFhigohoAuozr73WXebh0qqS2)\n\n### Игра Brain-GCD\nПользователю показывается два случайных числа, например, **25** **50**. Пользователь должен вычислить и ввести наибольший общий делитель этих чисел:\n\n[![asciicast](https://asciinema.org/a/dsxTskNy8nxPW9CFDmRdSuyrh.svg)](https://asciinema.org/a/dsxTskNy8nxPW9CFDmRdSuyrh)\n\n### Игра Brain-Progression\nПользователю показывается ряд чисел, образующий **арифметическую прогрессию**, заменив любое из чисел двумя точками. Игрок должен определить это число:\n\n[![asciicast](https://asciinema.org/a/hBlQbRpRspMOLZGvInWJjiVGi.svg)](https://asciinema.org/a/hBlQbRpRspMOLZGvInWJjiVGi)\n\n\n### Игра Brain-Prime\nПользователю показывается случайное число. И ему нужно ответить *yes*, если число простое, или *no* - если нет:\n\n[![asciicast](https://asciinema.org/a/C7sKZ9vcnhdEXdcdJ408hwJUG.svg)](https://asciinema.org/a/C7sKZ9vcnhdEXdcdJ408hwJUG)\n\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/botsiti/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/botsiti/python-project-49/actions)\n\n### Codeclimate Maintainability:\n[![Maintainability](https://api.codeclimate.com/v1/badges/d9677d92c9612c6f2509/maintainability)](https://codeclimate.com/github/botsiti/python-project-49/maintainability)\n',
    'author': 'batraz',
    'author_email': 'batrazbotsiev@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
